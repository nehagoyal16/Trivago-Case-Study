package AcceptanceTests;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.ParseException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Login_Search {

	public static WebDriver driver;
	
	//This method is executed first before the execution of any method
	@BeforeTest
	public void openBrowser() throws FileNotFoundException, IOException, ParseException, InterruptedException
	{
			
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Eigenaar\\eclipse-workspace1\\Selenium\\libs\\chromedriver.exe");
        driver = new ChromeDriver(); 
        driver.manage().window().maximize();
		driver.get("https://www.trivago.co.uk/"); 
		Thread.sleep(8000);        
	       
	}
	
	//This method is executed before the execution of every method
	@BeforeMethod
	public void TrivagoLogin() throws InterruptedException
	{
		
			//Enter the login credentials
	
			driver.findElement(By.xpath("//*[@id=\"js_navigation\"]/div/div[1]/button/span")).click();
			
			 //Enter the Email address and click on the next button
			driver.findElement(By.id("check_email")).sendKeys("goyalneha675@gmail.com");

			driver.findElement(By.id("login_email_submit")).click();

			// Enter the password and click on login button		
			Thread.sleep(4000);							
			driver.findElement(By.id("login_password")).sendKeys("nehagoyal16");
			driver.findElement(By.id("login_submit")).click();
					    
		}
						
	
	@Test
	public void TrivagoSearchHotels() throws InterruptedException
	{
		driver.findElement(By.xpath("//*[@id=\"querytext\"]")).sendKeys("Dusseldorf");
		driver.findElement(By.xpath("//span[contains(text(),'Check in')]")).click();
		driver.findElement(By.xpath("//*[@id=\"js-fullscreen-hero\"]/div[1]/div[2]/div[4]/div[2]/div/table/tbody/tr[2]/td[6]/time")).click();
		driver.findElement(By.xpath("//span[contains(text(),'Check out')]")).click();
		driver.findElement(By.xpath("//*[@id=\"js-fullscreen-hero\"]/div[1]/div[2]/div[4]/div[2]/div/table/tbody/tr[5]/td[5]/time")).click();
		
		driver.findElement(By.xpath("//*[@id=\"js-fullscreen-hero\"]/div[1]/div[2]/button[2]/span[2]")).click();
	
	}
	
	//This method is executed after the execution of every method
		@AfterMethod
		public void TrivagoLogout() throws InterruptedException
		{
			//Logout of Trivago
			Thread.sleep(4000);
			
	        WebElement signOut = driver.findElement(By.id("user"));
	     	
	        Actions actionSignOut = new Actions(driver);
	        actionSignOut.moveToElement(signOut).build().perform();
	        driver.findElement(By.xpath("//*[@id=\"user-text\"]/span[3]")).click();	
	       	      				
		}

	
	//This method is executed after all the test methods

	@AfterTest
	public void closeBrowser()
	{
		//Close the window(all open tabs)
		driver.quit();

    }
}